﻿using Egoshin.Classes;
using Egoshin.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Egoshin
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private IEnumerable<Product> _ProductList;
        public List<ProductType> ProductTypeList { get; set; }
        public IEnumerable<Product> ProductList { 
            get {
                var Result = _ProductList;
                if (ProductTypeFilterId > 0)
                    Result = Result.Where(
                        p => p.ProductTypeID == ProductTypeFilterId);
                if (SearchFilter != "")
                    Result = Result.Where(
                        p => p.Title.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0 ||
                            p.Description.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0 ||
                            p.ArticleNumber.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0
                    );

                switch (SortType)
                {
                    // сортировка по названию продукции
                    case 1:
                        Result = Result.OrderBy(p => p.Title);
                        break;
                    case 2:
                        Result = Result.OrderByDescending(p => p.Title);
                        break;
                    case 3:
                        Result = Result.OrderBy(p => p.ProductionWorkshopNumber);
                        break;
                    case 4:
                        Result = Result.OrderByDescending(p => p.ProductionWorkshopNumber);
                        break;
                    case 5:
                        Result = Result.OrderBy(p => p.MinCostForAgent);
                        break;
                    case 6:
                        Result = Result.OrderByDescending(p => p.MinCostForAgent);
                        break;
        

                }
                return Result;

            } 
            set {
                _ProductList = value;
                Invalidate();
            } 
        }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;

            Globals.DataProvider = new MySqlDataProvider();
            ProductList = Globals.DataProvider.GetProducts();

            ProductTypeList = Globals.DataProvider.GetProductTypes().ToList();
            ProductTypeList.Insert(0, new ProductType { Title = "Все типы" });

        }
        public string[] SortList { get; set; } = {
            "Без сортировки",
            "название по убыванию", 
            "название по возрастанию",
            "номер цеха по убыванию",
            "номер цеха по возрастанию",
            "цена по убыванию", 
            "цена по возрастанию" };

        private int SortType = 0;

        public event PropertyChangedEventHandler PropertyChanged;

        private void SortTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortType = SortTypeComboBox.SelectedIndex;
            Invalidate();
        }
        private void Invalidate()
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("ProductList"));
        }

        private int ProductTypeFilterId = 0;

        private void ProductTypeFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // запоминаем ID выбранного типа
            ProductTypeFilterId = (ProductTypeFilter.SelectedItem as ProductType).ID;
            Invalidate();
        }

        private void SearchFilterTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            SearchFilter = SearchFilterTextBox.Text;
            Invalidate();

        }
        private string SearchFilter = "";
 
    }
}
