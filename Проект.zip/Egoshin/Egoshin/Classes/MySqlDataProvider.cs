﻿using Egoshin.Model;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Egoshin.Classes
{
    class MySqlDataProvider : IDataProvider
    {
        private MySqlConnection Connection;

        public MySqlDataProvider()
        {
            try
            {
                Connection = new MySqlConnection(
                    "Server=kolei.ru;Database=esmirnov;port=3306;UserId=esmirnov;password=111103;");
            }
            catch (Exception)
            {
            }
        }

        public IEnumerable<Product> GetProducts()
        {
            List<Product> ProductList = new List<Product>();
            string Query = @"SELECT p.*, pt.TitleType From Product p, ProductType pt where pt.ID = ProductTypeID";

            try
            {
                // открываем соединение с сервером
                Connection.Open();
                try
                {
                    // создаем команду
                    MySqlCommand Command = new MySqlCommand(Query, Connection);
                    // получаем результат команды (массив строк)
                    MySqlDataReader Reader = Command.ExecuteReader();

                    // перебираем стоки
                    while (Reader.Read())
                    {
                        // создаем экземпляр класса 
                        Product NewProduct = new Product();
                        // и заполняем его поля
                        NewProduct.ID = Reader.GetInt32("ID");
                        NewProduct.Title = Reader.GetString("Title");
                        NewProduct.ProductTypeID = Reader.GetInt32("ProductTypeID");
                        NewProduct.ArticleNumber = Reader.GetString("ArticleNumber");
                        NewProduct.ProductionPersonCount = Reader.GetInt32("ProductionPersonCount");
                        NewProduct.ProductionWorkshopNumber = Reader.GetInt32("ProductionWorkshopNumber");
                        NewProduct.MinCostForAgent = Reader.GetInt32("MinCostForAgent");
                        NewProduct.ProductType = Reader.GetString("TitleType");
                        // Методы Get<T> не поддерживают работу с NULL
                        // для полей, в которых может встретиться NULL (а лучше для всех)
                        // используйте следующий синтаксис
                        NewProduct.Description = Reader["Description"].ToString();
                        NewProduct.Image = Reader["Image"].ToString();

                        

                        // добавляем экземпляр класса в список продуктов
                        ProductList.Add(NewProduct);
                    }
                }
                finally
                {
                    // обязательно закрываем соединение
                    // ресурсы сервера конечны
                    Connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return ProductList;
        }
        public IEnumerable<ProductType> GetProductTypes()
        {
            List<ProductType> productTypeList = new List<ProductType>();
            string Query = "SELECT * FROM ProductType";

            try
            {
                Connection.Open();
                try
                {
                    MySqlCommand Command = new MySqlCommand(Query, Connection);
                    MySqlDataReader Reader = Command.ExecuteReader();

                    while (Reader.Read())
                    {
                        ProductType NewProductType = new ProductType();
                        NewProductType.ID = Reader.GetInt32("ID");
                        NewProductType.Title = Reader.GetString("TitleType");

                        productTypeList.Add(NewProductType);
                    }
                }
                finally
                {
                    Connection.Close();
                }
            }
            catch (Exception)
            {
            }

            return productTypeList;

        }
    }

}
